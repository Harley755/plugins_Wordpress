=== Coming Soon, Under Construction & Maintenance Mode By Dazzler ===
Contributors: dazzlersoft
Donate link: http://dazzlersoftware.com/
Tags: admin, coming soon, coming soon page, coming soon wp, coming soon wordPress plugin, construction, countdown timer, email, gmail, landing page, launch, launch page, maintenance, maintenance mode, message, newsletter, notify, offline, preview, subscriber, ultimate coming soon page, ultimate landing page, unavailable, under construction, underconstruction,  under construction page, wordpress coming soon, wordpress landing page, wordpress maintenance mode, wordpress maintenance mode plugin, wordpress under construction, wordpress under construction page
Requires at least: 5.0
Tested up to: 5.8.1
Stable tag: 1.6.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An awesome wordpress coming soon plugin to manage your under construction website, under maintenance mode website and offline website
 
== Description ==

No. #1 wordpress coming soon plugin to perfectly manage your coming soon, under construction website, under maintenance mode website and offline website


https://www.youtube.com/watch?v=5_pLkUss53g
 

**Coming Soon**

= Coming Soon Wp provide a distinguished minimal coming soon page with responsive and moder design layout.It’s very easy to set up and customize. =


> <strong>Get Coming Soon Pro</strong><br />
> Try coming soon Pro plugin comes with advanced options and many more setting like 8 newsletters services (mailchimp, aweber, getresponse), access settings, 8 high quality designs templates and so more features.  <a href="https://goo.gl/4rSmH6"  title="coming soon wp">Click here to know more about coming soon pro plugin!</a>




### Check Demo

* [Coming Soon](http://demo.wpshopmart.com/coming-soon-wp/)
* [Pro Plugin - Live Demos](https://goo.gl/E6J2Tp)
* [Upgrade To Pro Now](https://goo.gl/4rSmH6)



### Features Of Plugin

* Turn On With A Click Of A Button
* Responsive Design 
* Clean Retina
* Build with Bootstrap
* Html5 supported
* Works with any WordPress Theme
* Css3 Animations
* Background Image Supported 
* Unlimited color Scheme
* Contact Info  Display Option
* 4 Social Profile Integrated
* Flexible and user-friendly setup
* Live Preview option
* Clean and well documented 
* Translation Ready, i18n Support
* Easy disable the section that you do not need
* Cross Browser Support


### CHECK MORE FREE WORDPRESS PLUGINS BY DAZZLERSOFT

* [Progress Bar](https://wordpress.org/plugins/progress-bar-wp/)
* [Team](https://wordpress.org/plugins/dazzlersoft-teams/)

### Customizable Settings

* Coming Soon Page Title 
* Page Description   
* SEO Title
* SEO Description 
* Google Analytics Script
* Social Profiles - facebook, Twitter, Linkedin, Google+
* Background Color Setting
* Background Image Setting
* Font Size
* Font Color
* Contact Info - Address, Contact Number, Email Address
* And many More..


### Pro Features


* Responsive Design 
* Clean Retina
* Build with Bootstrap 3.3.4
* 8 Designs Templates 
* 7+ Newsletter Option  
* 4+  Additional Pages 
* About US Page 
* Team Section
* Contact Info Section 
* Contact FOrm Integrated 
* Google Map Integrated 
* Service Page  
* 10 Background Slideshow 
* Youtube Video Background 
* Countdown Timer 
* Auto Launch 
* Access Control 
* Ip Access 
* User Access 
* Landing Page Option Access 
* Full SEO Control 
* Subscribers List 
* 16+ No. Of social Profile 
* Social Profile Drag And Drop 
* 500+ No. Google Fonts
* Mailchimp Newsletter Integrated
* Madmimi Newsletter Integrated
* Icontact Newsletter Integrated
* Constant Contact Newsletter Integrated
* Campaign Monitor Newsletter Integrated
* GetResponse Newsletter Integrated


### Check Demos

* [Pro Plugin - Live Demos](https://goo.gl/4rSmH6)
* [Upgrade To Pro Now](https://goo.gl/4rSmH6)




= Translators =

Please contribute to translate our plugin. Contact at `dazzlersoft(at)gmail(dot)com`.

== Installation ==

1. Upload the entire `coming-soon-wp` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to coming soon wp menu to customize this plugin.
4. Finally Enjoy it.

== Frequently Asked Questions ==

= what is coming soon plugin? =

coming soon pluign is very useful to manage your under maintenance webistes or non complete website.

= how it's work? =

you will need to just enabaled it. Then it's redirect your website to our coming soon page managed by you.


= is this coming soon plugin SEO friendly? =

Yes this SEO Compatible, you can add your google tracking code here and add your own meta info.


= I activated plugin it but i can't see your cominng soon page? =

Acces your website on different browser. And deactivate any cache plugin.

 

== Screenshots ==

1. screenshot 1  
2. screenshot 2
3. screenshot 3
4. screenshot 4
5. screenshot 5
6. screenshot 6
7. screenshot 7
8. screenshot 8
9. screenshot 9
10. screenshot 10


== Changelog ==

= 1.6.9 =
* Security issue resolved

= 1.6.7 =
* Compatible with WordPress 5.8 version
* Security issue resolved


= 1.6.3 =
* Compatible with WordPress 5.6 version

= 1.6.2 =
* minor issue resolved
* Compatible with WordPress 5.5.1 version

= 1.6.1 =
* minor issue resolved

= 1.5.9 =
* Compatible with WordPress 5.4 version

= 1.5.8 =
* Compatible with WordPress 5.3 version

= 1.5.7 =
* design issue resolve

= 1.5.6 =
* Compatible with wordpress 5.2.1 version

= 1.5.5 =
* Compatible with wordpress 5.1.1 version

= 1.5.4 =
* Compatible with wordpress 5.0 version

= 1.5.3 =
* Compatible with wordpress 4.9.8 version
* update some comments line

= 1.5.2 =
* Compatible with wordpress 4.9.7 version
* optimized plugin code 

= 1.5.1 =
*  Compatible with wordpress 4.9.6 version

= 1.5.0 =
* Minor bug reolved

= 1.4.9 =
* Minor issue reolved

= 1.4.8 =
* Minor css bug resolved

= 1.4.7 =
* upadate date count

= 1.4.6 =
* upadate ssl links

= 1.4.5 =
* upadate help comments

= 1.4.4 =
* Compatible with wordpress 4.9 version

= 1.4.3 =
* Minor issue resolved

= 1.4.2 =
* Compatible with wordpress 4.8.2 version

= 1.4.1 =
* Compatible with wordpress 4.8.1 version
* update some links and css code

= 1.4.0 =
* Compatible with wordpress 4.8 version

= 1.3.7 =
* Add some demo links and help button

= 1.3.6 =
* google analytics save problem resolved

= 1.3.5 =
* Minor Bug Resolved

= 1.3.4 =
* Add review link

= 1.3.3 =
* Resolve minor big

= 1.3.2 =
* update small css code

= 1.3.1 =
* Minor bug resolved

= 1.3 =
* Admin panel button conflict issue resolved 

= 1.2 =
* Remove Unused css 

= 1.1 =
* Minor link issue resolved

= 1.0 =
* Initial release.



$(document).ready(function() {	
	
	/*------------------------------
		VEGAS BACKGROUND
	------------------------------*/
	$.vegas({src:'assets/images/background.jpg'});
	
	
});


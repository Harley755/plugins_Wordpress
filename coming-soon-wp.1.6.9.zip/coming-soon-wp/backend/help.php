<?php 
if ( ! defined( 'ABSPATH' ) ) exit;

?>
<table class="form-table">
		<tr>
			<th><?php _e('Get Support','DAZZ_CSW_TEXT_DOMAIN'); ?></th>
		</tr>
		<tr class="radio-span" >
			<td>
					
				<a class="portfolio_read_more_btn " href="https://wordpress.org/support/plugin/coming-soon-wp" target="blank" ><?php _e('Get Support Now','DAZZ_CSW_TEXT_DOMAIN'); ?></a>
				
						
								
			</td>
			
		</tr>
		
		<tr>
			<th><?php _e('rate Us If you like this','DAZZ_CSW_TEXT_DOMAIN'); ?></th>
		</tr>
		<tr class="radio-span" >
			<td>
					
				<a class="portfolio_read_more_btn" target="_blank" style="background:#31a3dd;color:#fff;margin-right:10px;margin-bottom:10px;vertical-align:middle;font-weight:700;box-shadow: 0 0 26px rgba(0, 0, 0, 0.2);" href="https://wordpress.org/plugins/coming-soon-wp/"><span class="dashicons dashicons-star-filled"></span>
				<span class="dashicons dashicons-star-filled"></span>
				<span class="dashicons dashicons-star-filled"></span>
				<span class="dashicons dashicons-star-filled"></span>
				<span class="dashicons dashicons-star-filled"></span>  Rate Us</a>	
								
			</td>
			
		</tr>
		
		
</table>


<?php 
if ( ! defined( 'ABSPATH' ) ) exit;

?>
<table class="form-table">
		<tr>
			<th><?php _e('','DAZZ_CSW_TEXT_DOMAIN'); ?></th>
		</tr>
		<tr class="radio-span" >
			<td>				
				<div class="texture-layer">					
					<div class="wpsm_ac_h_b"><a class="btn btn-danger btn-lg " href="https://wpshopmart.com/plugins/coming-soon-pro/" target="_blank">Try Before Buy</a><a class="btn btn-success btn-lg " href="https://wpshopmart.com/coming-soon-pro-demo-page/" target="_blank">View Demos</a></div>
				</div>
				<br />
				<br />
				<a href="https://wpshopmart.com/plugins/coming-soon-pro/" target="_blank">	
					<img src="<?php echo DAZZ_CSW_PLUGIN_URL.'assets/images/pro.jpg'; ?>" style="width:100%;height:auto"  />
				</a>								
			</td>			
		</tr>		
</table>